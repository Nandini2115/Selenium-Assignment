Action()
{

	web_set_sockets_option("SSL_VERSION", "AUTO");

	web_add_auto_header("Accept-Language", 
		"en-US,en;q=0.9");

	web_url("jpetstore.aspectran.com", 
		"URL=https://jpetstore.aspectran.com/", 
		"Resource=0", 
		"RecContentType=text/html", 
		"Referer=", 
		"Snapshot=t1.inf", 
		"Mode=HTML", 
		LAST);

	lr_start_transaction("1_LaunchURL");

	web_websocket_send("ID=1", 
		"Buffer={\"messageType\":\"hello\",\"broadcasts\":{\"remote-settings/monitor_changes\":\"\\\"1790318207180\\\"\"},\"use_webpush\":true}", 
		"IsBinary=0", 
		LAST);

	/*Connection ID 1 received buffer WebSocketReceive0*/

	lr_end_transaction("1_LaunchURL",LR_AUTO);

	lr_start_transaction("2_category");

	web_link("Fish", 
		"Text=Fish", 
		"Ordinal=1", 
		"Snapshot=t2.inf", 
		LAST);

	lr_end_transaction("2_category",LR_AUTO);

	lr_think_time(27);

	lr_start_transaction("3_product");

	web_link("FI-FW-02", 
		"Text=FI-FW-02", 
		"Snapshot=t3.inf", 
		LAST);

	lr_end_transaction("3_product",LR_AUTO);

	lr_think_time(20);

	lr_start_transaction("4_itemid");

	web_link("EST-21", 
		"Text=EST-21", 
		"Snapshot=t4.inf", 
		LAST);

	lr_end_transaction("4_itemid",LR_AUTO);

	lr_start_transaction("5_addtocart");

	web_link("Add to Cart", 
		"Text=Add to Cart", 
		"Snapshot=t5.inf", 
		LAST);

	lr_end_transaction("5_addtocart",LR_AUTO);

	lr_start_transaction("6_checkout");

	web_link("Proceed to Checkout", 
		"Text=Proceed to Checkout", 
		"Snapshot=t6.inf", 
		LAST);

	lr_end_transaction("6_checkout",LR_AUTO);

	lr_start_transaction("7_login");

	web_submit_form("signon", 
		"Snapshot=t7.inf", 
		ITEMDATA, 
		"Name=username", "Value=yyyy2", ENDITEM, 
		"Name=password", "Value=yyyy2", ENDITEM, 
		LAST);

	lr_end_transaction("7_login",LR_AUTO);

	lr_start_transaction("8_continue");

	web_submit_form("newOrder", 
		"Snapshot=t8.inf", 
		ITEMDATA, 
		"Name=cardType", "Value=Visa", ENDITEM, 
		"Name=creditCard", "Value=999999999999999", ENDITEM, 
		"Name=expiryDate", "Value=12/2019", ENDITEM, 
		"Name=billToFirstName", "Value=mmm", ENDITEM, 
		"Name=billToLastName", "Value=nnn", ENDITEM, 
		"Name=billAddress1", "Value=hgffdtge", ENDITEM, 
		"Name=billAddress2", "Value=ghjfhgfgh", ENDITEM, 
		"Name=billCity", "Value=kdrtr", ENDITEM, 
		"Name=billState", "Value=Karnataka", ENDITEM, 
		"Name=billZip", "Value=583229", ENDITEM, 
		"Name=billCountry", "Value=India", ENDITEM, 
		"Name=shippingAddressRequired", "Value=<OFF>", ENDITEM, 
		LAST);

	lr_end_transaction("8_continue",LR_AUTO);

	lr_start_transaction("9_confirm");

	web_submit_form("submitOrder", 
		"Action=/order/submitOrder", 
		"Snapshot=t9.inf", 
		ITEMDATA, 
		LAST);

	lr_end_transaction("9_confirm",LR_AUTO);

	return 0;
}